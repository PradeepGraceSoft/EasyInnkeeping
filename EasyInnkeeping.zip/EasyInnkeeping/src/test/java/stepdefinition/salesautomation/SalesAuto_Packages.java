package stepdefinition.salesautomation;

import java.text.DecimalFormat;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.PG_SalesAutomation;
import utility.BaseClass;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : MAR-23-2023 Purpose : Contains the
 * sales automation's package related test cases menthods for basic / advance /
 * premium / platinum
 * 
 *********************************************/

public class SalesAuto_Packages {
	WebDriver driver;
	PG_SalesAutomation objsale;
	BaseClass objbase = new BaseClass(driver);
	String packAmount;
	DecimalFormat objdecimal = new DecimalFormat("##.00");
	
	public SalesAuto_Packages() {
		
	}
	

	@Given("Choose monthly with the basic package")
	public void choose_monthly_with_the_basic_package() throws Exception {
		objbase.pmsLogin("subscribe");
		objsale = objbase.getSalesAutomationInstance();
		objsale.MonthYearDropdown(1);
		objsale.PackageDropdown(1);
	}

	@And("Choose the no of {string}")
	public void choose_the_no_of(String units) throws Exception {
		objsale.UnitDropdown(units);
		packAmount = objdecimal.format(Float.parseFloat(objsale.getRoomAmount("Basic", units)));
	}

	@Then("Verify the summary has the right values")
	public void verify_the_summary_has_the_right_values() {
		//Package Amount | Item Total | One time Setup | Sub Total | Sales Discount | Sales Tax | Total payment Now | Charge On Next Billing Cycle
		objsale.Ast_InvoicePreview(packAmount,"0.00","0.00",packAmount,"0.00","0.00",packAmount,packAmount);
	}

	@When("Clicking on pay now should complete the subscription")
	public void clicking_on_pay_now_should_complete_the_subscription() {
		objsale.ClickPayNowButton();
		objsale.FillPaymentInfoComplete();
	}

	@Then("Subscription should be created on the PMS successfully")
	public void subscription_should_be_created_on_the_pms_successfully() {

	}

}
