package stepdefinition.onlineV3;

import java.text.DecimalFormat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.PG_OnlineBookingV3;
import pages.PG_PMSLeftMenus;
import pages.PG_Reservation;
import pages.PG_ReservationList;
import utility.BaseClass;
import utility.ConfigProperty;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : JUL-12-2023 Purpose : Contains the
 * Step Definitions for the Online Booking V3.
 * 
 *********************************************/

public class Regular_Seasonal_ExtraPerson_Weekend {

	Actions objActionclass;
	WebDriver driver;
	BaseClass objbase = new BaseClass(driver);
	PG_OnlineBookingV3 objOnlineV3;
	PG_Reservation objres;
	PG_ReservationList objlist;
	DecimalFormat decformat = new DecimalFormat("##.00");
	String roomrate;
	String statetaxval;
	String lodgtaxval;
	String epcadult;
	String epcchild;
	String statetax;
	String lodgingtax;
	String grandtot;
	String tottax;
	Integer nights;
	String roomtype;

	public Regular_Seasonal_ExtraPerson_Weekend() {
		ConfigProperty.getOnlineBookingV3ConfigProperty();
	}

	public void GetRoomRate(Integer nights, String roomname) {
		if (roomname == "regular" && nights == 1) {
			roomrate = ConfigProperty.objprop.get().getProperty("RegularRate");
		} else if (roomname == "regular" && nights == 2) {
			roomrate = ConfigProperty.objprop.get().getProperty("RegularRate2N");
		} else if (roomname == "seasonal" && nights == 1) {
			roomrate = ConfigProperty.objprop.get().getProperty("SeasonalRate");
		} else if (roomname == "seasonal" && nights == 2) {
			roomrate = ConfigProperty.objprop.get().getProperty("SeasonalRate2N");
		}
		statetaxval = ConfigProperty.objprop.get().getProperty("Statetax");
		lodgtaxval = ConfigProperty.objprop.get().getProperty("Lodgingtax");
		epcadult = ConfigProperty.objprop.get().getProperty("EPCAdult");
		epcchild = ConfigProperty.objprop.get().getProperty("EPCChild");
		statetax = decformat.format(Double.parseDouble(roomrate) * Double.parseDouble(statetaxval));
		lodgingtax = decformat.format(Double.parseDouble(roomrate) * Double.parseDouble(lodgtaxval));
		grandtot = decformat.format(Double.parseDouble(roomrate) + Double.parseDouble(statetax) + Double.parseDouble(lodgingtax));
		tottax = decformat.format(Double.parseDouble(statetax) + Double.parseDouble(lodgingtax));
	}
	
	// @AGILE1-TC-416 @regular
	@Given("Launch the online booking V3 and choose a regular room")
	public void launch_the_online_booking_v3_and_choose_a_regular_room() {
		objbase.LaunchOnlineBookingV3();
		objbase.ScrollPage();
		objOnlineV3 = objbase.getOnlineBookingV3Instance();
		objOnlineV3.RDChooseRoomType(ConfigProperty.objprop.get().getProperty("RegularRoomName"));
		roomtype = "regular";
	}

	@Then("Choose the dates for {int} and search")
	public void choose_the_dates_for_and_search(Integer days) throws InterruptedException {
		objOnlineV3.RDDatePickerEndDate(days);
		objOnlineV3.RDSearchButtonClick();
		nights = days;
	}

	@Then("Book a room and validate the booking summary showing correct values")
	public void book_a_room_and_validate_the_booking_summary_showing_correct_values() throws Exception {
		objOnlineV3.RSFirstRoomBookNowClick();
		objOnlineV3.RSCompleteBookClick();
	}

	@Then("In registration page, validate the calculation are showing correctly")
	public void in_registration_page_validate_the_calculation_are_showing_correctly() {
		GetRoomRate(nights, roomtype);
		objOnlineV3.AstRegPaymentDetails(roomrate, statetax, lodgingtax, grandtot);
	}

	@When("Completing the booking should save the reservation successfully")
	public void completing_the_booking_should_save_the_reservation_successfully() throws Exception {
		objOnlineV3.RGEnterGuestDetails();
		objOnlineV3.RGCompleteBooking();
		objOnlineV3.AstBookingConfirm();
	}

	@When("In thankyou page, it should show the right details as booked")
	public void in_thankyou_page_it_should_show_the_right_details_as_booked() {
		objOnlineV3.AstThankyouBookingDetails(roomrate, tottax, grandtot);
	}

	@Then("In PMS, it should show the right details as booked online")
	public void in_pms_it_should_show_the_right_details_as_booked_online() throws Exception {
		String Confirmnum = objOnlineV3.TKGetConfirmNumV3();
		objOnlineV3.OpenPMSReservation(Confirmnum);
		objres = objbase.getReservationInstance();
		objres.AstBookSummaryValues(roomrate, "0.00", "0.00", tottax, "0.00", grandtot, "0.00", grandtot, "Book Summary - ");
		objres.deleteButtonClick();
	}

	// @AGILE1-TC-417 @seasonal
	@Given("Launch the online booking V3 and choose a seasonal room")
	public void launch_the_online_booking_v3_and_choose_a_seasonal_room() {
		objbase.LaunchOnlineBookingV3();
		objbase.ScrollPage();
		objOnlineV3 = objbase.getOnlineBookingV3Instance();
		objOnlineV3.RDChooseRoomType(ConfigProperty.objprop.get().getProperty("SeasonalRoomName"));
		roomtype = "seasonal";
	}

	@After("@Regular,Seasonal,ExtraPersonandWeekendrates")
	public void teardown(Scenario scenario) throws Exception {
		objbase.Screenshot(scenario);
		objbase.browserClose();
	}

}
