package stepdefinition.onlineV3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.PG_OnlineBookingV3;
import utility.BaseClass;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : JUN-22-2023 Purpose : Contains the
 * Step Definitions for the Online Booking V3.
 * 
 *********************************************/

public class OnlineBookingV3 {

	Actions objActionclass;
	WebDriver driver;
	BaseClass objbase = new BaseClass(driver);
	PG_OnlineBookingV3 objOnlineV3;

	public OnlineBookingV3() {

	}

	@Given("Launch the V3 URL")
	public void launch_the_v3_url() {
		objbase.LaunchOnlineBookingV3();
	}

	@Then("Search and choose a room")
	public void search_and_choose_a_room() throws Exception {
		objOnlineV3 = objbase.getOnlineBookingV3Instance();
		objOnlineV3.RDSearchButtonClick();
		objOnlineV3.RSFirstRoomBookNowClick();
		objOnlineV3.RSCompleteBookClick();
	}

	@Then("Fill the guest details")
	public void fill_the_guest_details() {
		objOnlineV3.RGEnterGuestDetails();
	}

	@Then("Complete the booking")
	public void complete_the_booking() {
		objOnlineV3.RGCompleteBooking();
	}

	@After("@createres")
	public void teardown(Scenario scenario) throws Exception {
		objbase.Screenshot(scenario);
		objbase.browserClose();
	}
}
