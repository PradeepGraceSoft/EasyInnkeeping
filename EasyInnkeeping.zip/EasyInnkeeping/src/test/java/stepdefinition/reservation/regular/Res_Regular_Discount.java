package stepdefinition.reservation.regular;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.github.javafaker.Faker;

import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.PG_PMSLeftMenus;
import pages.PG_Report;
import pages.PG_Reservation;
import pages.PG_ReservationList;
import utility.BaseClass;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : FEB-04-2023 Purpose : Contains the
 * Step Definitions for the Regular Reservation Discount.
 * 
 *********************************************/

public class Res_Regular_Discount {

	Actions objActionclass;
	PG_PMSLeftMenus objPMSLeftMenus;
	PG_ReservationList objReservationList;
	PG_Reservation objReservation;
	PG_Report objReport;
	WebDriver driver;
	BaseClass objbase = new BaseClass(driver);
	Faker faker = new Faker();

	public Res_Regular_Discount() {

	}

	@Given("Create a reservation for one night one room for \"([^\\\"]*)\\\"$")
	public void create_a_reservation_for_one_night_one_room_for(String roomAmtVal) throws Exception {
		objbase.pmsLogin("continue");
		objPMSLeftMenus = objbase.getPMSLeftMenusInstance();
		objPMSLeftMenus.reservationListIconClick();
		objReservationList = objbase.getReservationListInstance();
		objReservationList.AddReservation();
		objReservation = objbase.getReservationInstance();
		objReservation.selectFirstRoom();
		objReservation.rateEditIconClick();
		objReservation.rateTotTxtBxInp(roomAmtVal);
		objReservation.ratePopSaveButtonClick();
	}

	@When("Adding the room discount percentage and room discount for \"([^\\\"]*)\\\"$")
	public void adding_the_room_discount_percentage_and_room_discount_for(String discountVal) throws Exception {
		objReservation.discountIconClick();
		objReservation.dispop_Drpdw_RoomDisPerClick();
		objReservation.dispop_Drpdw_disrateinp(discountVal);
		objReservation.dispop_Drpdw_AddAnoDis();
		objReservation.dispop_Drpdw_RoomDisClick();
		objReservation.dispop_Drpdw_disrateinp(discountVal);
		objReservation.dispop_Drpdw_SaveButtonClick();
	}

	@Then("It should add the right \\\"([^\\\"]*)\\\" on the booking summary for \\\"([^\\\"]*)\\\"$")
	public void it_should_add_the_right_on_the_booking_summary_for(String discountVal, String roomAmtVal)
			throws Exception {
		String expdiscountval = objReservation.calDiscountPerAndFlat(roomAmtVal, discountVal);
		String expTax = objReservation.calTax(roomAmtVal);
		String expPostTot = objReservation.calPostTaxTotal(roomAmtVal, expdiscountval, expTax);
		objReservation.AstBookSummaryValues(roomAmtVal, "0.00", "(" + expdiscountval + ")", expTax, "0.00",
				expPostTot, "", expPostTot, "Before Saving Reservation");
		objReservation.firstName(faker.name().firstName());
		objReservation.lastName(faker.name().lastName());
		objReservation.chooseAccCode("106");
		objReservation.saveButtonClick();
		objReservation.AstResSaved();
		objReservation.AstBookSummaryValues(roomAmtVal, "0.00", "(" +expdiscountval+ ")", expTax, "0.00", expPostTot, "0.00",
				expPostTot, "After Saving Reservation");
		objReservation.deleteButtonClick();
	}

	@After
	public void teardown(Scenario scenario) throws Exception {
		objbase.Screenshot(scenario);
		objbase.browserClose();
	}
}
