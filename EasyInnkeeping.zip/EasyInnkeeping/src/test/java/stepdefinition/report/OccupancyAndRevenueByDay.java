/*
 * package stepdefinition.report;
 * 
 * import io.cucumber.java.en.Given; import io.cucumber.java.en.Then; import
 * io.cucumber.java.en.When; import utility.BaseClass;
 * 
 * public class OccupancyAndRevenueByDay extends BaseClass {
 * 
 * 
 * 
 * public OccupancyAndRevenueByDay() {
 * 
 * }
 * 
 * 
 * @Given("Create a 3 days reservation with EPC and Discount") public void
 * create_a_days_reservation_with_EPC_and_Discount() throws Exception {
 * pmsLogin("continue"); objPMSLeftMenus = BaseClass.getPMSLeftMenusInstance();
 * objPMSLeftMenus.reservationListIconClick();
 * objReservationList=BaseClass.getReservationListInstance();
 * objReservationList.AddReservation();
 * objReservation=BaseClass.getReservationInstance();
 * objReservation.startDate("02/09/2025"); objReservation.noOfNights("3");
 * objReservation.selectFirstRoom(); objReservation.noOfAdult("3");
 * objReservation.noOfChild("1"); objReservation.firstName("Occupancy");
 * objReservation.lastName("Revenue"); objReservation.chooseAccCode("106");
 * objReservation.saveButtonClick(); objReservation.assertResSaved();
 * objReservation.closeButtonClick(); }
 * 
 * @When("Running the report for occupancy and revenue by day for the arrival and departure days"
 * ) public void
 * running_the_report_for_occupancy_and_revenue_by_day_for_the_arrival_and_departure_days
 * () throws Exception { objPMSLeftMenus.reportIconClick(); objReport =
 * BaseClass.getReportInstance(); objReport.OccRevDayClick();
 * objReport.CustomDateInput("02/09/2025", "02/12/2025");
 * objReport.ShowButtonCLick();
 * 
 * }
 * 
 * @Then("It should show the arrival count and guest count on arrival day")
 * public void it_should_show_the_arrival_count_and_guest_count_on_arrival_day()
 * throws Exception { objReport = BaseClass.getReportInstance();
 * objReport.AssertOccRevDayRpt("arrival"); }
 * 
 * @Then("It should show the departure count and guest count on departure day")
 * public void
 * it_should_show_the_departure_count_and_guest_count_on_departure_day() throws
 * Exception {
 * 
 * 
 * }
 * 
 * @Then("It should show the stay overcount and guest count on stay over days")
 * public void
 * it_should_show_the_stay_overcount_and_guest_count_on_stay_over_days() throws
 * Exception{
 * 
 * 
 * }
 * 
 * @Then("It should show the right value for Income Tax Discount Total Income Average Daily Rate Total Rev PAR and grand total"
 * ) public void
 * it_should_show_the_right_value_for_Income_Tax_Discount_Total_Income_Average_Daily_Rate_Total_Rev_PAR_and_grand_total
 * () throws Exception {
 * 
 * 
 * }
 * 
 * 
 * 
 * 
 * @Given("Block a room on the calendar") public void
 * block_a_room_on_the_calendar() throws Exception {
 * 
 * 
 * }
 * 
 * @When("Generating the report for the blocked day") public void
 * generating_the_report_for_the_blocked_day() throws Exception {
 * 
 * 
 * }
 * 
 * @Then("It should show count on the blocked column only") public void
 * it_should_show_count_on_the_blocked_column_only() throws Exception {
 * 
 * 
 * } }
 */