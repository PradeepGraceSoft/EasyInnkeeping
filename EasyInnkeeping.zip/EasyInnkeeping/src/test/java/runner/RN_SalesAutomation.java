package runner;



import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import utility.ConfigProperty;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : FEB-04-2023 Purpose : Contains the
 * Runner method for the Regular Reservation Discount.
 * 
 *********************************************/

@CucumberOptions(features = "src/test/resources/feature/salesautomation/packages/Packages.feature", 
glue = "stepdefinition.salesautomation", plugin = {
		"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "pretty",
		"json:target/JSON/SalesAutomation/Cucumber.json" }, dryRun=false
		, tags = "@AGILE1-TC-159")

public class RN_SalesAutomation extends AbstractTestNGCucumberTests {
	@Parameters("browsertype")
	@BeforeClass
	public void loadConfig(@Optional("") String browser) {
		ConfigProperty.getConfigProperty();
		ConfigProperty.getSalesAutoConfigProperty();
		if(!"".equals(browser)) {
			ConfigProperty.objprop.get().setProperty("browser", browser);
		}
	}
}

