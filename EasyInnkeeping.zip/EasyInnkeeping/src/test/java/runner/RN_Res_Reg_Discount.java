package runner;


import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import utility.ConfigProperty;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : FEB-04-2023 Purpose : Contains the
 * Runner method for the Regular Reservation Discount.
 * 
 *********************************************/

@CucumberOptions(features = "src/test/resources/feature/reservation/regular/Reg_Discount.feature", glue = "stepdefinition/reservation/regular", plugin = {
		"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "pretty",
		"json:target/JSON/Cucumber.json" })

public class RN_Res_Reg_Discount extends AbstractTestNGCucumberTests {
	@Parameters("browsertype")
	@BeforeClass
	public void loadConfig(@Optional("") String browser) {
		ConfigProperty.getConfigProperty();
		if(!"".equals(browser)) {
			ConfigProperty.objprop.get().setProperty("browser", browser);
		}
	}
}
