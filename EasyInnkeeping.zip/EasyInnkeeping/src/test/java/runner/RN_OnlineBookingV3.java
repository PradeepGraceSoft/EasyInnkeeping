package runner;

import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import utility.ConfigProperty;

	
	/******************************************
	 * 
	 * Developer : Pradeep Kumar S Created Date : JUN-22-2023 Purpose : Contains the
	 * Runner method for the Online Booking V3.
	 * 
	 *********************************************/

	@CucumberOptions(features = "src/test/resources/feature/onlineV3/", 
			glue = "stepdefinition/onlineV3", plugin = {
			"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "pretty",
			"json:target/JSON/Cucumber.json"})
			//,tags = "@createres")

	public class RN_OnlineBookingV3 extends AbstractTestNGCucumberTests {
		@Parameters("browsertype")
		@BeforeClass
		public void loadConfig(@Optional("") String browser) throws SQLException {
			ConfigProperty.getConfigProperty();
			ConfigProperty.getDBConnectionConfigProperty();
			if(!"".equals(browser)) {
				ConfigProperty.objprop.get().setProperty("browser", browser);
			}
		}
}
