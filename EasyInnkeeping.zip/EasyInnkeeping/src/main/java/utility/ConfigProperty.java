package utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : MAR-16-2023 Purpose : It loads the
 * configuration files data on "envariables" package
 * 
 *********************************************/

public class ConfigProperty {

	public static ThreadLocal<Properties> objprop = null;
	static Properties objpr = null;

	/* Local */ static String Local = "src/main/java/envariables/Local";
	/* SVN */ static String SVN = "src/main/java/envariables/SVN";
	/* Trunk */ static String Trunk = "src/main/java/envariables/Trunk";
	/* Live */ static String Live = "src/main/java/envariables/Live";
	/* Sales Automation */ static String SalesAuto = "src/main/java/envariables/SalesAutomation";
	/* Online Booking V3 */ static String OnlineV3 = "src/test/resources/testdata/OnlineBookingV3";
	/* Online Booking V3 */ static String DBConnection = "src/main/java/envariables/DBConnection";

	public static void getConfigProperty() {
		if (objprop == null && objpr == null) {
			objprop = new ThreadLocal<Properties>();
			objpr = new Properties();
		}
		try (FileInputStream objip = new FileInputStream(Trunk)) {
			objpr.load(objip);
			objprop.set(objpr);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void getSalesAutoConfigProperty() {
		if (objprop == null && objpr == null) {
			objprop = new ThreadLocal<Properties>();
			objpr = new Properties();
		}
		try (FileInputStream objip = new FileInputStream(SalesAuto)) {
			objpr.load(objip);
			objprop.set(objpr);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void getOnlineBookingV3ConfigProperty() {
		if (objprop == null && objpr == null) {
			objprop = new ThreadLocal<Properties>();
			objpr = new Properties();
		}
		try (FileInputStream objip = new FileInputStream(OnlineV3)) {
			objpr.load(objip);
			objprop.set(objpr);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void getDBConnectionConfigProperty() {
		if (objprop == null && objpr == null) {
			objprop = new ThreadLocal<Properties>();
			objpr = new Properties();
		}
		try (FileInputStream objip = new FileInputStream(DBConnection)) {
			objpr.load(objip);
			objprop.set(objpr);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
