package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.PG_OnlineBookingV3;
import pages.PG_PMSLeftMenus;
import pages.PG_Report;
import pages.PG_Reservation;
import pages.PG_ReservationList;
import pages.PG_SalesAutomation;

public class BaseClass {

	/******************************************
	 * 
	 * Developer : Pradeep Kumar S Created Date : FEB-04-2023 Purpose : Contains the
	 * frequently used methods and this method will be extended to all classes.
	 * 
	 *********************************************/

	private WebDriver driver;
	private PG_PMSLeftMenus objPMSLeftMenus = null;
	private PG_ReservationList objReservationList = null;
	private PG_Reservation objReservation = null;
	private PG_Report objReport = null;
	private PG_SalesAutomation objsalepg = null;
	private PG_OnlineBookingV3 objOnlineV3 = null;
	private WebDriverWait objwait = null;
	private Actions objact = null;
	private Statement objsmt;
	Connection objconnect;

	public BaseClass(WebDriver driver) {
		this.driver = driver;
	}

	// Opening the Browser of Chrome / Chromeheadless / Firefox / Edge and Safari
	// The browser values are taken from envariables package >> Files >> Browser
	// value and if runs from testng.xml file
	public void browserLaunch() {
		String browserValue = ConfigProperty.objprop.get().getProperty("browser");
		if (browserValue.equals("chromeheadless")) {
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--headless");
			options.addArguments("--window-size=1920x1080");
			driver = new ChromeDriver(options);
			driver.manage().deleteAllCookies();
		} else if (browserValue.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
		} else if (browserValue.equals("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
		} else if (browserValue.equals("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
		} else if (browserValue.equals("safari")) {
			WebDriverManager.safaridriver().setup();
			driver = new SafariDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
		}
	}

	// Windows Handling. Use to navigate to diffferent windows from parent window
	public void navigateWindow(WebDriver driver, String Popup) {
		List<String> mainpage = new ArrayList<String>(driver.getWindowHandles());
		if (Popup == "0") {
			List<String> mainpage2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(mainpage2.get(0));
		}
		if (Popup == "1") {
			List<String> mainpage2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(mainpage2.get(1));
		} else if (Popup == "2") {
			List<String> mainpage2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(mainpage2.get(2));
		} else if (Popup == "3") {
			List<String> mainpage2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(mainpage2.get(3));
		} else if (Popup == "4") {
			List<String> mainpage2 = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(mainpage2.get(4));
		}
	}

	public void ScrollPage() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(5000,40)");
	}

	// Initializing Cookie to browser for PMS login and Super Admin to avoid the two
	// Factor Authentication
	public void initiCookies(String access, String proshortname) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 7);
		if (access == "user") {
			String encodedpropshortname = Base64.getEncoder().encodeToString((proshortname).getBytes());
			Cookie ck = new Cookie("LoginValidationCookies", "ShortName=" + encodedpropshortname + "&MACAddress=" + ConfigProperty.objprop.get().getProperty("MACAddress"), ConfigProperty.objprop.get()
					.getProperty("CookieServer"), "/", cal.getTime(), false);
			driver.manage().addCookie(ck);
		}

		else if (access == "admin") {
			String encodedpropshortname = Base64.getEncoder().encodeToString((ConfigProperty.objprop.get().getProperty("AdminShort")).getBytes());
			Cookie ck = new Cookie("LoginValidationCookies", "ShortName=" + encodedpropshortname + "&MACAddress=" + ConfigProperty.objprop.get().getProperty("MACAddress"), ConfigProperty.objprop.get()
					.getProperty("CookieServer"), "/", cal.getTime(), false);
			driver.manage().addCookie(ck);
		}

	}

	// PMS login on same browser from V3 session
	public void pmsLoginV3() throws Exception {
		driver.get(ConfigProperty.objprop.get().getProperty("VerifyLogin"));
		initiCookies("user", ConfigProperty.objprop.get().getProperty("V3PropertyShortName"));
		driver.findElement(By.xpath(".//*[@id='ShortName']")).sendKeys(ConfigProperty.objprop.get().getProperty("V3PropertyShortName"));
		driver.findElement(By.xpath(".//*[@id='userid']")).sendKeys(ConfigProperty.objprop.get().getProperty("V3LoginName"));
		driver.findElement(By.xpath(".//*[@id='password']")).sendKeys(ConfigProperty.objprop.get().getProperty("V3Password"));
		driver.findElement(By.xpath(".//*[@id='Button1']")).click();
		Thread.sleep(5000);
		try {
			driver.findElement(By.xpath("//button[@onclick][1]")).isDisplayed();
			driver.findElement(By.xpath("//button[@onclick][2]")).click();
		} catch (NoSuchElementException e) {

		}

	}

	// PMS login for a demo property which shows continue and subscribe alert
	public void pmsLogin(String suborcont) throws Exception {
		browserLaunch();
		driver.get(ConfigProperty.objprop.get().getProperty("VerifyLogin"));
		initiCookies("user", ConfigProperty.objprop.get().getProperty("PropertyShortName"));
		driver.findElement(By.xpath(".//*[@id='ShortName']")).sendKeys(ConfigProperty.objprop.get().getProperty("PropertyShortName"));
		driver.findElement(By.xpath(".//*[@id='userid']")).sendKeys(ConfigProperty.objprop.get().getProperty("LoginName"));
		driver.findElement(By.xpath(".//*[@id='password']")).sendKeys(ConfigProperty.objprop.get().getProperty("Password"));
		driver.findElement(By.xpath(".//*[@id='Button1']")).click();
		Thread.sleep(5000);
		objact = getActionInstance();
		objact.sendKeys(Keys.F5);
		Thread.sleep(5000);
		boolean popupcheck = driver.findElement(By.xpath("//button[@onclick][1]")).isDisplayed();
		if (popupcheck == true) {
			if (suborcont == "subscribe") {
				driver.findElement(By.xpath("//button[@onclick][1]")).click();
			}
			if (suborcont == "continue") {
				driver.findElement(By.xpath("//button[@onclick][2]")).click();
			}
		}
	}

	// Launch Browser and Online Booking URL
	public void LaunchOnlineBookingV3() {
		browserLaunch();
		driver.get(ConfigProperty.objprop.get().getProperty("OnlineV3Link"));
	}

	// Login Super admin for searching a property
	public void SuperAdmin(String propertyName) throws Exception {
		driver.get(ConfigProperty.objprop.get().getProperty("VerifyLogin"));
		initiCookies("admin", ConfigProperty.objprop.get().getProperty("AdminShort"));
		driver.findElement(By.xpath(".//*[@id='ShortName']")).sendKeys(ConfigProperty.objprop.get().getProperty("AdminShort"));
		driver.findElement(By.xpath(".//*[@id='userid']")).sendKeys(ConfigProperty.objprop.get().getProperty("AdminLogin"));
		driver.findElement(By.xpath(".//*[@id='password']")).sendKeys(ConfigProperty.objprop.get().getProperty("AdminPass"));
		driver.findElement(By.xpath(".//*[@id='Button1']")).click();
		this.navigateWindow(driver, "1");
		driver.findElement(By.name("txtSearch")).sendKeys(propertyName);
		driver.findElement(By.name("search")).click();
		driver.findElement(By.xpath("//*[@id='myTab1Content']/table/tbody/tr[2]/td[3]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value='Display features']")).click();
	}

	// Takes screenshot when the scenario gets failed
	public void Screenshot(Scenario scenario) {
		if (scenario.isFailed()) {
			try {
				String path = scenario.getName() + " - " + System.currentTimeMillis();
				byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
				scenario.attach(screenshot, "image/png", path);
			} catch (WebDriverException wde) {
				System.err.println(wde.getMessage());
			} catch (ClassCastException cce) {
				cce.printStackTrace();
			}
		}
	}

	// Object Creation for - Each Page Classes / PageWait / ActionClass
	public PG_PMSLeftMenus getPMSLeftMenusInstance() {
		if (objPMSLeftMenus == null) {
			objPMSLeftMenus = new PG_PMSLeftMenus(driver);
		}
		return objPMSLeftMenus;
	}

	public PG_ReservationList getReservationListInstance() {
		if (objReservationList == null) {
			objReservationList = new PG_ReservationList(driver);
		}
		return objReservationList;
	}

	public PG_Reservation getReservationInstance() {
		if (objReservation == null) {
			objReservation = new PG_Reservation(driver);
		}
		return objReservation;
	}

	public PG_Report getReportInstance() {
		if (objReport == null) {
			objReport = new PG_Report(driver);
		}
		return objReport;
	}

	public PG_SalesAutomation getSalesAutomationInstance() {
		if (objsalepg == null) {
			objsalepg = new PG_SalesAutomation(driver);
		}
		return objsalepg;
	}

	public PG_OnlineBookingV3 getOnlineBookingV3Instance() {
		if (objOnlineV3 == null) {
			objOnlineV3 = new PG_OnlineBookingV3(driver);
		}
		return objOnlineV3;
	}

	public WebDriverWait getPageWaitsInstance() {
		if (objwait == null) {
			objwait = new WebDriverWait(driver, 60);
		}
		return objwait;
	}

	public Actions getActionInstance() {
		if (objact == null) {
			objact = new Actions(driver);
		}
		return objact;
	}

	// DB Connection
	public void DBUpdate(String query) throws SQLException {
		String propId = ConfigProperty.objprop.get().getProperty("PropertyIDVersion3");
		try {
			if (propId != "") {
				objconnect = DriverManager.getConnection(ConfigProperty.objprop.get().getProperty("dbURL"), ConfigProperty.objprop.get().getProperty("dbusername"), ConfigProperty.objprop.get()
						.getProperty("dbpass"));
				objsmt = objconnect.createStatement();
				objsmt.executeUpdate(query + propId);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		finally {
			objsmt.close();
			objconnect.close();
		}
	}

	// Closing the browser window if one child window is opened
	public void BrowserClose_Window1() {
		navigateWindow(driver, "1");
		driver.close();
		navigateWindow(driver, "0");
		driver.close();
	}

	// Closing the browser window if two child windows are opened
	public void BrowserClose_Window2() {
		navigateWindow(driver, "2");
		driver.close();
		navigateWindow(driver, "1");
		driver.close();
		navigateWindow(driver, "0");
		driver.close();
	}

	// Closing the browser and quiting the driver
	public void browserCloseOnly() {
		driver.close();
	}

	// Closing the browser and quiting the driver
	public void browserClose() {
		driver.close();
		driver.quit();
	}
}
