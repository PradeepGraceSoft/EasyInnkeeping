package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import utility.BaseClass;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : FEB-08-2023 Purpose : Contains the
 * reservation list / Find Reservation elements and methods
 * 
 * 
 *********************************************/

public class PG_ReservationList {

	SoftAssert softast = new SoftAssert();
	WebDriverWait objwait;
	WebDriver driver;
	BaseClass objbase;

	// ***************** Page Elements *********************************
	@FindBy(xpath = "//span[text()='Add']")
	WebElement eleAddRes;

	@FindBy(id = "mat-input-1")
	WebElement eleSearchBox;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()='Find ']")
	WebElement eleFindBtn;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-FullName mat-column-FullName ng-star-inserted']")
	WebElement eleFirstGuestList;

	@FindBy(xpath = "(//input[@type='checkbox'])[2]")
	WebElement eleFirstChkBx;

	@FindBy(xpath = "//span[text()='Delete']")
	WebElement eleDeleteBtn;

	@FindBy(xpath = "//span[text()='OK']")
	WebElement eledeleteOKBtn;

	// ***************** Page Initialization ***************************
	public PG_ReservationList(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		if (objbase == null) {
			objbase = new BaseClass(driver);
		}
	}

	// ***************** Page Methods *********************************
	public void AddReservation() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleAddRes));
		eleAddRes.click();
	}

	public void OpenReservation(String ConfirmNum) {
		eleSearchBox.sendKeys(ConfirmNum);
		eleFindBtn.click();
		eleFirstGuestList.click();
	}

	public void DeleteReservation(String resNum) {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleSearchBox));
		eleSearchBox.sendKeys(resNum);
		eleFindBtn.click();
		eleFirstChkBx.click();
		eleDeleteBtn.click();
		driver.switchTo().alert().accept();
		objwait.until(ExpectedConditions.visibilityOf(eledeleteOKBtn));
		eledeleteOKBtn.click();
	}
}