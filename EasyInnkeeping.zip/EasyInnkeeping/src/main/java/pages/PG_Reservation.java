package pages;

import java.text.DecimalFormat;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import utility.BaseClass;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : FEB-08-2023 Purpose : Contains the
 * Reservation elements and methods
 * 
 * 
 *********************************************/

public class PG_Reservation {

	String[] BookSummResultValue;
	WebElement BookingSummValues;
	WebDriver driver;
	Actions objact;
	SoftAssert objsoftast = new SoftAssert();
	BaseClass objbase;
	DecimalFormat decformat = new DecimalFormat("##.00");
	WebDriverWait objwait;

	// ***************** Page Elements *********************************
	// ======================= Header =======================
	@FindBy(xpath = "//h2[text()='Reservation #:']/child::span")
	WebElement eleResNo;

	@FindBy(xpath = "//label[text()='Status : ']")
	WebElement eleStatusLabel;

	// Room Selection
	@FindBy(id = "startDateControl")
	WebElement eleStartDt;

	@FindBy(id = "nightsControl")
	WebElement eleNoOfNight;

	@FindBy(xpath = "(//mat-form-field[@floatlabel='always'])[5]")
	WebElement eleRoomDropEnable;

	@FindBy(xpath = "(//span[@class='mat-option-text'])[1]")
	WebElement eleSelFirstRoom;

	@FindBy(name = "adults")
	WebElement eleAdult;

	@FindBy(name = "children")
	WebElement eleChild;

	@FindBy(xpath = "//mat-icon[text()='edit']")
	WebElement eleRateEditIcon;

	@FindBy(xpath = "(//strong[text()='Total Rate']//following::div)[1]/input")
	WebElement eleRatePopTotTxtBx;

	@FindBy(xpath = "(//span[@class='mat-button-wrapper' and text()='Save']) [2]")
	WebElement eleRatePopSave;

	// ======================= Guest Info =======================
	@FindBy(xpath = "//input[@formcontrolname='firstName']")
	WebElement eleFirstName;

	@FindBy(xpath = "//input[@formcontrolname='lastName']")
	WebElement eleLastName;

	// ======================= Booking Summary =======================
	@FindBy(xpath = "//label[text()='Unit Total ']//following::label[1]")
	WebElement eleBsUnitrate;

	@FindBy(xpath = "//label[text()='Extra Person Charge ']//following::label[1]")
	WebElement eleBsEpc;

	@FindBy(xpath = "//label[text()='Discounts ']//following::label[1]")
	WebElement eleBsDiscount;

	@FindBy(xpath = "//label[text()='Tax ']//following::div[1]")
	WebElement eleBsTax;

	@FindBy(xpath = "//label[text()='Miscellenous ']//following::div[1]")
	WebElement eleBsMisc;

	@FindBy(xpath = "//label[text()='Post Tax Total ']//following::div[1]")
	WebElement eleBsPostTaxTot;

	@FindBy(xpath = "//label[text()='Total Paid ']//following::div[1]")
	WebElement eleBsPaid;

	@FindBy(xpath = "//div[text()='Amount Due ']//following::div[1]")
	WebElement eleBsDue;

	@FindBy(xpath = "//label[text()='Discounts ']//following::button[1]")
	WebElement eleBsDisAddIcon;

	// ======================= Discount Popup =======================
	@FindBy(name = "discountName")
	WebElement eleDisPopDrpDwClick;

	@FindBy(xpath = "//span[text()=' Room Discount % ']")
	WebElement eleDisPopDrpDwRoomDisPer;

	@FindBy(xpath = "//span[text()=' Room Discount ']")
	WebElement eleDisPopDrpDwRoomDis;

	@FindBy(name = "discountrate")
	WebElement eleDisRateInp;

	@FindBy(xpath = "//span[text()=' + Add Another Discount']")
	WebElement eleDisAddAnoDis;

	@FindBy(xpath = "//span[text()='Apply']")
	WebElement eleDisSaveBtn;

	// =============== Payment Info =======================
	@FindBy(id = "mat-input-11")
	WebElement eleChooseAccCode;

	// =============== Footer Buttons =======================
	@FindBy(xpath = "//span[text()='Save']")
	WebElement eleSaveBtn;

	@FindBy(xpath = "(//span[@class='mat-button-wrapper' and text()='Delete'])[2]")
	WebElement eleDeleteBtn;

	@FindBy(xpath = "//span[text()='Close']")
	WebElement eleCloseBtn;

	// ***************** Page Initialization ***************************
	public PG_Reservation(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		if (objbase == null) {
			objbase = new BaseClass(driver);
		}
	}

	// ***************** Page Methods *********************************
	// ======================= Room Selection =======================
	public void startDate(String valFromDate) throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleStartDt));
		eleStartDt.sendKeys(Keys.chord(Keys.CONTROL, "a"), valFromDate);
	}

	public void noOfNights(String valNights) throws Exception {
		eleNoOfNight.sendKeys(Keys.chord(Keys.CONTROL, "a"), valNights);
		Thread.sleep(2000);
	}

	public void selectFirstRoom() throws Exception {
		Thread.sleep(2000);
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleRoomDropEnable));
		eleRoomDropEnable.click();
		objwait.until(ExpectedConditions.visibilityOf(eleSelFirstRoom));
		eleSelFirstRoom.click();
		Thread.sleep(2000);
		objact = objbase.getActionInstance();
		objact.sendKeys(Keys.TAB).build().perform();
	}

	public void noOfAdult(String valAdultCount) throws Exception {
		eleAdult.sendKeys(Keys.chord(Keys.CONTROL, "a"), valAdultCount);
		Thread.sleep(2000);
	}

	public void noOfChild(String valChildCount) throws Exception {
		eleChild.sendKeys(Keys.chord(Keys.CONTROL, "a"), valChildCount);
		Thread.sleep(2000);
	}

	// ======================= Rate Change Popup =======================
	public void rateEditIconClick() {
		eleRateEditIcon.click();
	}

	public void rateTotTxtBxInp(String valRate) throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleRatePopTotTxtBx));
		eleRatePopTotTxtBx.sendKeys(Keys.chord(Keys.CONTROL, "a"), valRate);
	}

	public void ratePopSaveButtonClick() {
		eleRatePopSave.click();
	}

	// ======================= Guest Info =======================
	public void firstName(String valFirstName) {
		eleFirstName.sendKeys(valFirstName);
		objact = objbase.getActionInstance();
		objact.sendKeys(Keys.TAB).build().perform();
	}

	public void lastName(String valLastName) {
		eleLastName.sendKeys(valLastName);
		objact = objbase.getActionInstance();
		objact.sendKeys(Keys.TAB).build().perform();
	}

	// ======================= Payment Info =======================
	public void chooseAccCode(String valAccCode) {
		eleChooseAccCode.sendKeys(valAccCode);
	}

	// ======================= Footer Buttons =======================
	public void saveButtonClick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleSaveBtn));
		eleSaveBtn.click();
	}

	public void deleteButtonClick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleDeleteBtn));
		objact = objbase.getActionInstance();
		Thread.sleep(2000);
		objact.moveToElement(eleDeleteBtn).click().build().perform();
		objwait.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().accept();
	}

	public void closeButtonClick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleCloseBtn));
		eleCloseBtn.click();
	}

	// ======================= Booking Summary =======================
	public String calDiscountPerAndFlat(String roomAmount, String disAmount) {
		return decformat.format(
				Float.parseFloat(disAmount) + ((Float.parseFloat(roomAmount) * (Float.parseFloat(disAmount) / 100))));

	}

	public String calTax(String roomAmount) {
		return decformat.format(Float.parseFloat(roomAmount) * Float.parseFloat("0.1495"));
	}

	public String calPostTaxTotal(String roomAmount, String disAmount, String taxamount) {
		return decformat
				.format(Float.parseFloat(roomAmount) - Float.parseFloat(disAmount) + Float.parseFloat(taxamount));
	}

	// ======================= Discount Popup =======================
	public void discountIconClick() {
		eleBsDisAddIcon.click();
	}

	public void dispop_Drpdw_RoomDisPerClick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleDisPopDrpDwClick));
		eleDisPopDrpDwClick.click();
		objwait.until(ExpectedConditions.visibilityOf(eleDisPopDrpDwRoomDisPer));
		eleDisPopDrpDwRoomDisPer.click();
		eleDisPopDrpDwClick.sendKeys(Keys.TAB);
	}

	public void dispop_Drpdw_RoomDisClick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleDisPopDrpDwClick));
		eleDisPopDrpDwClick.click();
		objwait.until(ExpectedConditions.visibilityOf(eleDisPopDrpDwRoomDis));
		eleDisPopDrpDwRoomDis.click();
		eleDisPopDrpDwClick.sendKeys(Keys.TAB);
	}

	public void dispop_Drpdw_disrateinp(String discountVal) throws Exception {
		Thread.sleep(2000);
		eleDisRateInp.sendKeys(discountVal);
	}

	public void dispop_Drpdw_AddAnoDis() throws Exception {
		Thread.sleep(2000);
		eleDisAddAnoDis.click();
	}

	public void dispop_Drpdw_SaveButtonClick() throws Exception {
		Thread.sleep(2000);
		eleDisSaveBtn.click();
	}

	// ======================= Assert Methods =======================
	public String AstResSaved() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.elementToBeClickable(eleDeleteBtn));
		objwait.until(ExpectedConditions.visibilityOf(eleStatusLabel));
		objsoftast.assertNotSame(eleResNo.getText(), "0", "Reservation Saved Sucessfully");
		objsoftast.assertAll();
		return eleResNo.getText();
	}

	public void AstBookSummaryValues(String expUnit, String expEpc, String expDis, String expTax, String expMisc,
			String expPostTot, String expPaid, String expDue, String message) throws Exception {
		WebElement[] BookingSummValues = { eleBsUnitrate, eleBsEpc, eleBsDiscount, eleBsTax, eleBsMisc, eleBsPostTaxTot,
				eleBsPaid, eleBsDue };
		String[] summaryLabelNames = { " - UnitRate - ", " - EPC - ", " - Discount - ", " - Tax - ", " - MISC - ",
				" - PostTaxTotal - ", " - Amount Paid - ", " - Amount Due - " };
		String[] expBookingSummValues = { expUnit, expEpc, expDis, expTax, expMisc, expPostTot, expPaid, expDue };

		for (int i = 0; i < BookingSummValues.length; i++) {
			BookSummResultValue = new String[BookingSummValues.length];
			BookSummResultValue[i] = BookingSummValues[i].getText();
			Thread.sleep(1000);
			objsoftast.assertEquals(BookSummResultValue[i], expBookingSummValues[i], message + summaryLabelNames[i]);
		}
		objsoftast.assertAll();
	}
}
