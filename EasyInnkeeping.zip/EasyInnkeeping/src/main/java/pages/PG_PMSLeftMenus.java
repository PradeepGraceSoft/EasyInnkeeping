package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.BaseClass;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : FEB-08-2023 Purpose : Contains the
 * PMS left menus such as Dashboard, Reservation, Calendar and so on
 * 
 * 
 *********************************************/

public class PG_PMSLeftMenus {

	Actions objActionclass;
	PG_PMSLeftMenus objPMSLeftMenus;
	PG_ReservationList objReservationList;
	PG_Reservation objReservation;
	PG_Report objReport;
	WebDriver driver;
	WebDriverWait objwait;
	BaseClass objbase;

	// ***************** Page Elements *********************************
	@FindBy(xpath = "//a[@routerlink='/list']")
	WebElement eleReslistIcon;

	@FindBy(xpath = "//a[@routerlink='/reports']")
	WebElement eleReportIcon;

	// ***************** Page Initialization ***************************
	public PG_PMSLeftMenus(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		if (objbase == null) {
			objbase = new BaseClass(driver);
		}

	}

	// ***************** Page Methods *********************************
	public void reservationListIconClick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleReslistIcon));
		eleReslistIcon.click();
	}

	public void reportIconClick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleReportIcon));
		eleReportIcon.click();
	}
}
