package pages;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.github.javafaker.Faker;

import utility.BaseClass;
import utility.ConfigProperty;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : MAR-22-2023 Purpose : Contains
 * Sales Automation page elements
 * 
 * 
 *********************************************/

public class PG_SalesAutomation {
	SoftAssert objsoftast = new SoftAssert();
	Properties envarsa;
	FileInputStream tempsa;
	WebDriver driver;
	BaseClass objbase;
	WebDriverWait objwait;
	Actions objact;
	Statement objsmt;
	String roomAmount;

	// Page Elements
	// Package Section
	@FindBy(name = "paymentType")
	WebElement eleMonthYearDropdown;

	@FindBy(name = "PackageList")
	WebElement elePackageDropdown;

	@FindBy(name = "UnitList")
	WebElement eleUnitDropdown;
	
	@FindBy(id = "packageAmount")
	WebElement elePackAmount;

	// Inoice Preview
	@FindBy(xpath = "//p[text()='Package Amount']/following::td[1]/p")
	WebElement elePacAmt;

	@FindBy(xpath = "//p[text()='Item Total']/following::td[1]/p")
	WebElement eleItemTot;

	@FindBy(xpath = "//p[text()='One time Setup']/following::td[1]/p")
	WebElement eleOneTimeSetup;

	@FindBy(xpath = "//p[text()='Sub Total']/following::td[1]/p")
	WebElement eleSubTot;

	@FindBy(xpath = "//p[text()='Sales Discount']/following::td[1]/p")
	WebElement eleDis;

	@FindBy(xpath = "//p[text()='Sales Tax']/following::td[1]/p")
	WebElement eleSaleTax;

	@FindBy(xpath = "//p[text()='Total payment Now']/following::td[1]/p")
	WebElement eleTotPayNow;

	@FindBy(xpath = "//p[text()='Charge On Next Billing Cycle']/following::td[1]/p")
	WebElement eleChargeNextBillCycle;

	@FindBy(id = "btnpayNow")
	WebElement payNowBtn;

	// Payment Page
	@FindBy(xpath = "//select[@name='cardTypeList']/option[2]")
	WebElement eleVisaCardType;

	@FindBy(name = "cardNumber")
	WebElement eleCardNum;

	@FindBy(xpath = "//select[@name='expiryYear']/option[5]")
	WebElement eleExpYear;

	@FindBy(id = "txtCVVNo")
	WebElement eleCVV;

	@FindBy(id = "txtFirstName")
	WebElement eleFirstName;

	@FindBy(id = "txtLastName")
	WebElement eleLastName;

	@FindBy(id = "txtCompanyName")
	WebElement eleCompanyName;

	@FindBy(id = "txtAddress")
	WebElement eleAddress;

	@FindBy(id = "txtCity")
	WebElement eleCity;

	@FindBy(id = "txtState")
	WebElement eleState;

	@FindBy(id = "txtCountry")
	WebElement eleCountry;

	@FindBy(id = "txtPinCode")
	WebElement eleZip;

	@FindBy(id = "txtPhoneNumber")
	WebElement eleContactNum;

	@FindBy(id = "txtEmail")
	WebElement eleEmail;

	@FindBy(id = "chkAgree")
	WebElement eleAgreeChkBox;

	@FindBy(id = "IframeButton")
	WebElement elePayCompleteBtn;

	// Page Initialization
	public PG_SalesAutomation(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		if (objbase == null) {
			objbase = new BaseClass(driver);
		}
	}

	// Page Methods
	public void MonthYearDropdown(int planchosen) {
		driver.switchTo().frame("iframeValue");
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleMonthYearDropdown));
		Select mydropdown = new Select(eleMonthYearDropdown);
		mydropdown.selectByIndex(planchosen); // Index0 - Yearly | Index1 - Monthly
	}

	public void PackageDropdown(int packageeik) {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(elePackageDropdown));
		Select pcdropdown = new Select(elePackageDropdown);
		pcdropdown.selectByIndex(packageeik); // Index0 - Basic | Index1 - Advanced | Index2 - Premium | Index3 - Platinum
	}

	public void UnitDropdown(String unit) {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleUnitDropdown));
		Select untdropdown = new Select(eleUnitDropdown);
		untdropdown.selectByValue(unit);
	}

	public void ClickPayNowButton() {
		payNowBtn.click();
	}

	public void FillPaymentInfoComplete() {
		Faker objfak = new Faker();
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleVisaCardType));
		eleVisaCardType.click();
		objwait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("tx_iframe_tokenExIframeDiv"))));
		driver.switchTo().frame(driver.findElement(By.id("tx_iframe_tokenExIframeDiv")));
		objwait.until(ExpectedConditions.visibilityOf(eleCardNum));
		eleCardNum.sendKeys("4111111111111111");
		driver.switchTo().parentFrame();
		eleExpYear.click();
		eleCVV.sendKeys("111");
		eleFirstName.sendKeys(objfak.name().firstName());
		eleLastName.sendKeys(objfak.name().lastName());
		eleCompanyName.sendKeys("GraceSoft Test");
		eleAddress.sendKeys(objfak.address().buildingNumber());
		eleCity.sendKeys(objfak.address().city());
		eleState.sendKeys(objfak.address().state());
		eleCountry.sendKeys(objfak.address().country());
		eleZip.sendKeys(objfak.address().zipCode());
		eleContactNum.sendKeys("123456798");
		eleEmail.sendKeys(ConfigProperty.objprop.get().getProperty("SubscriberEmailAddress"));
		eleAgreeChkBox.click();
		elePayCompleteBtn.click();
		objwait.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().accept();
	}

	public String getRoomAmount(String packageName, String noOfUnit) {
		if (noOfUnit.equals("1-20")) {
			roomAmount = ConfigProperty.objprop.get().getProperty(packageName + "_1-20");
		} else if (noOfUnit.equals("21-40")) {
			roomAmount = ConfigProperty.objprop.get().getProperty(packageName + "_21-40");
		} else if (noOfUnit.equals("41-60")) {
			roomAmount = ConfigProperty.objprop.get().getProperty(packageName + "_41-60");
		} else if (noOfUnit.equals("61-80")) {
			roomAmount = ConfigProperty.objprop.get().getProperty(packageName + "_61-80");
		} else if (noOfUnit.equals("81-100")) {
			roomAmount = ConfigProperty.objprop.get().getProperty(packageName + "_81-100");
		}
		return roomAmount;

	}

	// Asserting Methods
	// Package Amount | Item Total | One time Setup | Sub Total | Sales Discount |
	// Sales Tax | Total payment Now | Charge On Next Billing Cycle
	public void Ast_InvoicePreview(String expPackAmount, String expItemTot, String expOneTimeSet, String expSubTot, String expDis, String expTax, String expTotPay, String expNxtCycle) {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(elePackAmount));
		WebElement[] eleInvoice = { elePacAmt, eleItemTot, eleOneTimeSetup, eleSubTot, eleDis, eleSaleTax, eleTotPayNow, eleChargeNextBillCycle };
		String[] expvalues = { expPackAmount, expItemTot, expOneTimeSet, expSubTot, expDis, expTax, expTotPay, expNxtCycle };
		String[] labelNames = { "Package Amount", "Item Total", "One time Setup", "Sub Total", "Sales Discount", "Sales Tax", "Total payment Now", "Charge On Next Billing Cycle" };

		for (int i = 0; i < eleInvoice.length; i++) {
			String[] actgetvalue = new String[eleInvoice.length];
			actgetvalue[i] = eleInvoice[i].getText();
			objsoftast.assertEquals(actgetvalue[i], expvalues[i], labelNames[i]);
		}
		objsoftast.assertAll();
	}

	public void DB_DeleteSubscription() throws SQLException {
		ConfigProperty.getConfigProperty();
		try (Connection objconnect = DriverManager.getConnection(ConfigProperty.objprop.get().getProperty("dbURL"), ConfigProperty.objprop.get().getProperty("dbusername"), ConfigProperty.objprop.get()
				.getProperty("dbpass"));) {

			String propId = ConfigProperty.objprop.get().getProperty("PropertyID");
			objsmt = objconnect.createStatement();
			objsmt.executeQuery("delete from Gracesoft_Orders where Property_Id=" + propId);
			objsmt.executeQuery("delete from Gracesoft_OrderDetails where PropertyId=" + propId);
			objsmt.executeQuery("delete from Gracesoft_CurrentOrders where PropertyId=" + propId);
			objsmt.executeQuery("delete from Gracesoft_PaymentHistory where PropertyId=" + propId);
			objsmt.executeQuery("delete from Gracesoft_PayLaterDetails where PropertyId=" + propId);
			objsmt.executeQuery("update login set demo=1 where property_id" + propId);
		}
	}
}
