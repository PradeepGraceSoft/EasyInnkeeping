package pages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import utility.BaseClass;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : FEB-10-2023 Purpose : Contains the
 * report page elements and methods
 * 
 *********************************************/

public class PG_Report {
	WebDriver driver;
	Actions objact;
	WebDriverWait objwait;
	BaseClass objbase;
	SoftAssert objsoftast = new SoftAssert();

	// ***************** Page Elements *********************************
	@FindBy(xpath = "//mat-panel-title[text()=' Occupancy ']")
	WebElement ele_occupancydropdown;

	@FindBy(xpath = "//div[text()='Occupancy and Revenue By Day']")
	WebElement ele_occrevdaymenu;

	@FindBy(xpath = "//mat-radio-button[@value='Custom']")
	WebElement ele_customdatechkbx;

	@FindBy(name = "startDate")
	WebElement ele_customstartdt;

	@FindBy(name = "endDate")
	WebElement ele_customenddt;

	@FindBy(xpath = "//span[text()='Show']")
	WebElement ele_showbtn;

	@FindBy(xpath = "//tfoot[@role='rowgroup']//child::td")
	WebElement ele_grandtot;

	// Occupancy and Revenue By Day
	@FindBy(xpath = "(//tbody[@role='rowgroup']//child::tr)[1]//child::td[4]")
	WebElement ele_arrcount;

	// ***************** Page Initialization ***************************
	public PG_Report(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		if (objbase == null) {
			objbase = new BaseClass(driver);
		}
	}

	// ***************** Page Methods *********************************
	public void OccRevDayClick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(ele_occupancydropdown));
		ele_occupancydropdown.click();
		objwait.until(ExpectedConditions.visibilityOf(ele_occrevdaymenu));
		ele_occrevdaymenu.click();
	}

	public void CustomDateInput(String fromdt, String todt) throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(ele_customdatechkbx));
		ele_customdatechkbx.click();
		objwait.until(ExpectedConditions.visibilityOf(ele_customstartdt));
		objact = objbase.getActionInstance();
		objact.sendKeys(Keys.TAB).sendKeys(Keys.BACK_SPACE).build().perform();
		objact.sendKeys(Keys.TAB).sendKeys(Keys.BACK_SPACE).build().perform();
		ele_customstartdt.sendKeys(fromdt);
		ele_customenddt.sendKeys(todt);
	}

	public void ShowButtonCLick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(ele_showbtn));
		ele_showbtn.click();
	}

	// Assertion Methods
	public void AssertOccRevDayRpt(String column) throws Exception {
		Thread.sleep(5000);

		if (column == "arrival") {
			System.out.println("IINNNSSSIDE");
			List<WebElement> arrList = driver.findElements(By.xpath(
					"//td[@class='mat-cell cdk-cell cdk-column-Arrivals mat-column-Arrivals text-left ng-star-inserted']"));

			for (int i = 0; i < arrList.size(); i++) {

				String arr = new String();
				arr = arrList.get(i).getText();

			}

			objsoftast.assertEquals(arrList.get(0), "1");
			objsoftast.assertEquals(arrList.get(1), "0");
			objsoftast.assertEquals(arrList.get(2), "0");
			objsoftast.assertEquals(arrList.get(3), "0");
			objsoftast.assertAll();

		}

		if (column == "departure") {
			List<WebElement> depList = driver.findElements(By.xpath(
					"//td[@class='mat-cell cdk-cell cdk-column-Departures mat-column-Departures text-left ng-star-inserted']"));
			List<String> dep_all_elements = new ArrayList<>();
			for (int i = 0; i < depList.size(); i++) {
				dep_all_elements.add(depList.get(i).getText());
			}

		}
		if (column == "stayover") {
			List<WebElement> stayList = driver.findElements(By.xpath(
					"//td[@class='mat-cell cdk-cell cdk-column-stayover mat-column-stayover text-left ng-star-inserted']"));
			List<String> stay_all_elements = new ArrayList<>();
			for (int i = 0; i < stayList.size(); i++) {
				stay_all_elements.add(stayList.get(i).getText());
			}
		}
	}
}
