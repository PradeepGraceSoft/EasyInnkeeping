package pages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;

import com.github.javafaker.Faker;

import utility.BaseClass;
import utility.ConfigProperty;

/******************************************
 * 
 * Developer : Pradeep Kumar S Created Date : JUN-21-2023 Purpose : Contains the
 * WebElement of all the OnlineBooking V3 Pages such as Room details, Result,
 * Registration, Thankyou and induvidual booking
 * 
 ********************************************/

public class PG_OnlineBookingV3 {

	Actions objActionclass;
	WebDriver driver;
	WebDriverWait objwait;
	BaseClass objbase;
	PG_PMSLeftMenus objmenu;
	PG_ReservationList objlist;
	PG_Reservation objres;
	SoftAssert objsoftast = new SoftAssert();
	Assertion hardAssert = new Assertion();

	// ***************** Page Elements *********************************
	// Room Details
	@FindBy(xpath = "//button[@type=' button']")
	WebElement eleSearchBtn;

	@FindBy(name = "ROOM TYPES")
	WebElement eleroomtypeDpdw;

	// Result
	@FindBy(xpath = "(//button[@id='submit'])[1]")
	WebElement eleFirstRoomBtn;

	@FindBy(xpath = "//button[@class='comp']")
	WebElement eleCompBookBtn;

	// Registration
	// Payment Details
	@FindBy(xpath = "(//p[text()='Room Total:']//following::div/p)[1]")
	WebElement elePDRoomAmount;

	@FindBy(xpath = "(//p[text()='Room Total:']//following::div/p)[2]")
	WebElement elePDStateTax;

	@FindBy(xpath = "(//p[text()='Room Total:']//following::div/p)[3]")
	WebElement elePDLodingTax;

	@FindBy(xpath = "//b[text()='GrandTotal:']//following::div[1]")
	WebElement elePDGrandTotal;

	// Guest Details & Payment
	@FindBy(xpath = "//input[@name='firstname']")
	WebElement eleFirstName;

	@FindBy(xpath = "//input[@name='lastname']")
	WebElement eleLastName;

	@FindBy(xpath = "//input[@name='Email']")
	WebElement eleEmail;

	@FindBy(xpath = "//input[@name='Phone']")
	WebElement elePhone;

	@FindBy(xpath = "//input[@name='address']")
	WebElement eleAddress;

	@FindBy(xpath = "//input[@name='city']")
	WebElement eleCity;

	@FindBy(xpath = "//input[@name='state']")
	WebElement eleState;

	@FindBy(xpath = "//input[@name='country']")
	WebElement eleCountry;

	@FindBy(xpath = "//input[@name='userPincode']")
	WebElement eleZip;

	@FindBy(xpath = "//input[@name='Custom1']")
	WebElement eleCustom1;

	@FindBy(xpath = "//input[@name='Custom2']")
	WebElement eleCustom2;

	@FindBy(xpath = "//input[@name='Custom3']")
	WebElement eleCustom3;

	@FindBy(xpath = "//input[@name='Custom4']")
	WebElement eleCustom4;

	@FindBy(xpath = "//input[@name='Custom5']")
	WebElement eleCustom5;

	@FindBy(xpath = "//select[@name='cardType']//option[2]")
	WebElement eleVISACard;

	@FindBy(xpath = "//select[@name='cardType']//option[3]")
	WebElement eleMasterCard;

	@FindBy(xpath = "//input[@name='cardNumber']")
	WebElement eleCCNumber;

	@FindBy(xpath = "//input[@name='User Card Name']")
	WebElement eleCCName;

	@FindBy(xpath = "//select[@name='expiry-year']//option[5]")
	WebElement eleCCExpYear;

	@FindBy(xpath = "//input[@name='userAgree']")
	WebElement eleAgreeChkBox;

	@FindBy(xpath = "//button[text()='Complete Booking']")
	WebElement eleCompleteBook;

	// Thank You Booking
	@FindBy(xpath = "//h5[contains(text(), 'Your Reservation Confirmed')]")
	WebElement eleBookconfimText;

	@FindBy(xpath = "//p[text()='Room Charge:']//following::div[1]/p[1]")
	WebElement eleTkRoomAmt;

	@FindBy(xpath = "//p[text()='Room Charge:']//following::div[1]/p[2]")
	WebElement eleTkTax;

	@FindBy(xpath = "//h5[text()='Total Price:']//following::div[1]/p[1]")
	WebElement eleTkGrdtot;

	@FindBy(xpath = "//p[text()='Booking Number:']//following::div[1]/p[1]")
	WebElement eletkconfirmnum;

	// ***************** Page Initialization ***************************
	public PG_OnlineBookingV3(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		if (objbase == null) {
			objbase = new BaseClass(driver);
		}

	}

	// ***************** Page Methods *********************************
	public void RDChooseRoomType(String roomtypename) {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleroomtypeDpdw));
		Select rmdpdw = new Select(eleroomtypeDpdw);
		rmdpdw.selectByVisibleText(roomtypename);
	}

	public void RDDatePickerEndDate(int days) throws InterruptedException {
		if (days == 2) {
			driver.findElement(By.xpath("(//label[text()='Check-out']//following::input)[2]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//div[@tabindex=0]/following::div[1]/div")).click();

		}

		if (days == 3) {
			driver.findElement(By.xpath("(//label[text()='Check-out']//following::input)[2]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//div[@tabindex=0]/following::div[2]/div")).click();
		}

	}

	public void RDSearchButtonClick() {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleSearchBtn));
		eleSearchBtn.click();
	}

	public void RSFirstRoomBookNowClick() {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleFirstRoomBtn));
		eleFirstRoomBtn.click();
	}

	public void RSCompleteBookClick() throws Exception {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleCompBookBtn));
		Thread.sleep(2000);
		eleCompBookBtn.click();
	}

	public void RGEnterGuestDetails() {
		Faker objfak = new Faker();
		objwait = objbase.getPageWaitsInstance();
		eleFirstName.sendKeys(objfak.name().firstName().replaceAll("'", ""));
		eleLastName.sendKeys(objfak.name().lastName().replaceAll("'", ""));
		eleEmail.sendKeys("tester1@gracesoft.com");
		elePhone.sendKeys("123456799");
		eleAddress.sendKeys(objfak.address().buildingNumber());
		eleCity.sendKeys(objfak.address().city());
		eleState.sendKeys(objfak.address().state());
		eleCountry.sendKeys(objfak.address().country());
		eleZip.sendKeys(objfak.address().zipCode());

		WebElement[] customFields = { eleCustom1, eleCustom2, eleCustom3, eleCustom4, eleCustom5 };
		for (WebElement elemnt : customFields) {
			try {
				if (elemnt.isDisplayed()) {
					elemnt.sendKeys(objfak.name().firstName());
				}
			} catch (Exception e) {

			}
		}

		try {
			if (eleVISACard.isDisplayed()) {
				eleVISACard.click();
				driver.switchTo().frame(driver.findElement(By.name("tx_iframe_tokenExIframeDiv")));
				eleCCNumber.sendKeys("4111111111111111");
				driver.switchTo().parentFrame();
				eleCCName.sendKeys(objfak.name().fullName());
				eleCCExpYear.click();
			}
		} catch (Exception e) {

		}
	}

	public void RGCompleteBooking() {
		eleAgreeChkBox.click();
		eleCompleteBook.click();
	}

	public String TKGetConfirmNumV3() {
		return eletkconfirmnum.getText();
	}

	// ********** Assertion Methods ************
	public void BookingSummary() {

	}

	public void AstRegPaymentDetails(String exprmamt, String expstatax, String explodtax, String expgrdtot) {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(elePDRoomAmount));
		WebElement[] paydetval = { elePDRoomAmount, elePDStateTax, elePDLodingTax, elePDGrandTotal };
		String[] exppaydetval = { exprmamt, expstatax, explodtax, expgrdtot };
		String[] strarr = new String[paydetval.length];
		for (int i = 0; i < paydetval.length; i++) {
			try {
				if (paydetval[i].isDisplayed()) {
					strarr[i] = paydetval[i].getText().replaceAll("[$ ]", "");
					String actpaydetval = String.format("%.2f", Double.parseDouble(strarr[i]));
					objsoftast.assertEquals(actpaydetval, exppaydetval[i]);
				}
			} catch (Exception e) {
				System.out.println("Exception Found in PGOnlineV3 - AstRegPaymentDetails");

			}
		}
		objsoftast.assertAll();
	}

	public void AstBookingConfirm() {
		objwait = objbase.getPageWaitsInstance();
		hardAssert.assertTrue(objwait.until(ExpectedConditions.urlContains("EasyWebRez/tnk")));
	}

	public void AstThankyouBookingDetails(String exptkrmamt, String exptktax, String exptkgrdtot) {
		objwait = objbase.getPageWaitsInstance();
		objwait.until(ExpectedConditions.visibilityOf(eleTkRoomAmt));
		WebElement[] tkval = { eleTkRoomAmt, eleTkTax, eleTkGrdtot };
		String[] exptkval = { exptkrmamt, exptktax, exptkgrdtot };
		String[] strarrtk = new String[tkval.length];
		for (int i = 0; i < tkval.length; i++) {
			try {
				if (tkval[i].isDisplayed()) {
					strarrtk[i] = tkval[i].getText().replaceAll("[$ ]", "");
					String actpaydetval = String.format("%.2f", Double.parseDouble(strarrtk[i]));
					objsoftast.assertEquals(actpaydetval, exptkval[i]);
				}
			} catch (Exception e) {
				System.out.println("Exception Found in PGOnlineV3 - AstThankyouBookingDetails");

			}
		}
		objsoftast.assertAll();
	}

	public void OpenPMSReservation(String Confirmnum) throws Exception {
		objbase.pmsLoginV3();
		objmenu = objbase.getPMSLeftMenusInstance();
		objmenu.reservationListIconClick();
		objlist = objbase.getReservationListInstance();
		objlist.OpenReservation(Confirmnum);
	}

	// ******** DB Updates *********
	public void DBUpdateLeadDayZero() throws SQLException {
		objbase.DBUpdate("UPDATE property SET Leadtime = '0' where property_id=");
	}

}
